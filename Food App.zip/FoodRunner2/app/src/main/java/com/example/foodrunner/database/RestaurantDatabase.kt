package com.example.foodrunner.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.foodrunner.database.OrderDao
import com.example.foodrunner.database.OrderEntity
import com.example.foodrunner.database.RestaurantDao
import com.example.foodrunner.database.RestaurantEntity

@Database(
    entities = [RestaurantEntity::class, OrderEntity::class],
    version = 1,
    exportSchema = false
)
abstract class RestaurantDatabase : RoomDatabase() {

    abstract fun restaurantDao(): RestaurantDao

    abstract fun orderDao(): OrderDao

}
