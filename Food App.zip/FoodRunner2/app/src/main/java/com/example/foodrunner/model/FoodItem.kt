package com.example.foodrunner.model

data class FoodItem(val id: String?, val name: String?, val cost: Int?)
