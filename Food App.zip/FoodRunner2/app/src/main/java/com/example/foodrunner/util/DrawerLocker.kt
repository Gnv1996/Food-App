package com.example.foodrunner.util

interface DrawerLocker {
    fun setDrawerEnabled(enabled: Boolean)
}